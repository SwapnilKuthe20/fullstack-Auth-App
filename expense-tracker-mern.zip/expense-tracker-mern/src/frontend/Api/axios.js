import axios from "axios";
import { BaseUrl } from "../BaseUrl/BaseUrl";
// import { logoutUser } from "../utils/auth";

// Create custom axios instance
const api = axios.create({
    baseURL: BaseUrl,
    withCredentials: true, // allow sending cookies (for refresh token)
});

// ✅ Request Interceptor: Attach access token automatically
api.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem("accessToken");
        if (token) {
            config.headers["Authorization"] = `Bearer ${token}`;
        }
        return config;
    },
    (error) => Promise.reject(error)
);

// 🔄 Response Interceptor: Handle 401 & refresh access token
api.interceptors.response.use(
    (response) => response,

    async (error) => {
        const originalRequest = error.config;

        if (error.response?.status === 401 && !originalRequest._retry) {
            originalRequest._retry = true;

            try {
                // Refresh token request
                const res = await api.post("/auth/refreshToken");

                const newAccessToken = res.data.accessToken;

                // Save new access token
                localStorage.setItem("accessToken", newAccessToken);

                // Retry original request with new token
                originalRequest.headers["Authorization"] = `Bearer ${newAccessToken}`;
                return api(originalRequest);
            } catch (refreshError) {
                console.log("Refresh token failed:", refreshError.message);

                // Logout the user if refresh fails
                // logoutUser();
            }
        }

        return Promise.reject(error);
    }
);

export default api;
